import React from "react";

export default function Login(props) {
  return <div className="upload-document">{/* <div>Login</div> */}</div>;
}
