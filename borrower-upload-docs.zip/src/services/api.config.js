// Development Configuration

const base_url = "https://fcnode6.faircent.com";
const app_id = "865b07d22fab123d4101a11a6e327455";
const app_name = "FSIGP";



export { base_url, app_id, app_name }